"""Test suite for NEAT Flappy Bird AI."""
